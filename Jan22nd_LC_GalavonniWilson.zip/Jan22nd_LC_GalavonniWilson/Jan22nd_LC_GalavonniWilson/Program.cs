﻿//Mis 3013 January 22, 2024
// Galavonni Wilson 113506288

/*
datatype fucntionname(parameters)
{
    function body
        many lines of code
    return datatype variable
}
*/

char getLG(double grade)
{

    char r;
    if (grade >=90)
    {
        r = 'A';
    }
    else if (grade >=80)
    {
        r= 'B';
    }
    else if (grade >= 70)
    {
        r= 'C';

    }
    else if (grade >= 60)
    {
        r= 'D';

    }
    else 
    {
        r= 'F';

    }
    return r;


}



int add(int n1, int n2)
{
    int r;
    r = n1 + n2;
    return r;
}
int n;
n = add(20, 10);
Console.WriteLine(n);

char LG;
LG = getLG(76.6);
Console.WriteLine(LG);


Console.ReadLine();



